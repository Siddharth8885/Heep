# Heep

Mobile-first marketplace for local help with escrow, GPS check-ins, proof milestones, wallet, ratings, chat.

See `backend/` (FastAPI + SQLModel) and `mobile/` (Expo/React Native).

Quickstart in each folder.
