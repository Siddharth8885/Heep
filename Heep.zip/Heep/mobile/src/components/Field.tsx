import React from 'react';
import { View, Text, TextInput } from 'react-native';
export default function Field({label, value, onChangeText, keyboardType='default', multiline=false}: any) {
  return (
    <View style={{ marginVertical: 6 }}>
      <Text style={{ fontWeight: '600', marginBottom: 4 }}>{label}</Text>
      <TextInput value={value} onChangeText={onChangeText} keyboardType={keyboardType} multiline={multiline}
        style={{ borderWidth: 1, borderColor: '#ccc', padding: 10, borderRadius: 8 }} />
    </View>
  );
}
