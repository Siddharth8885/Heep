import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import RoleSelect from './screens/RoleSelect';
import SignUp from './screens/SignUp';
import CreateTask from './screens/CreateTask';
import AvailableTasks from './screens/AvailableTasks';
import TaskDetail from './screens/TaskDetail';
import EarlyProof from './screens/EarlyProof';
import FinalProof from './screens/FinalProof';
import Rating from './screens/Rating';
import Wallet from './screens/Wallet';
import Chat from './screens/Chat';
export type RootStackParamList = {
  SignUp: undefined; RoleSelect: undefined; CreateTask: undefined; AvailableTasks: undefined;
  TaskDetail: { task: any }; EarlyProof: { taskId: number }; FinalProof: { taskId: number };
  Rating: { taskId: number }; Wallet: undefined; Chat: { taskId: number; title: string };
};
const Stack = createStackNavigator<RootStackParamList>();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="SignUp">
        <Stack.Screen name="SignUp" component={SignUp} options={{ title: 'Sign In' }} />
        <Stack.Screen name="RoleSelect" component={RoleSelect} options={{ title: 'Choose Role' }} />
        <Stack.Screen name="CreateTask" component={CreateTask} options={{ title: 'Create Task' }} />
        <Stack.Screen name="AvailableTasks" component={AvailableTasks} options={{ title: 'Available Tasks' }} />
        <Stack.Screen name="TaskDetail" component={TaskDetail} options={{ title: 'Task' }} />
        <Stack.Screen name="EarlyProof" component={EarlyProof} options={{ title: 'Early Progress' }} />
        <Stack.Screen name="FinalProof" component={FinalProof} options={{ title: 'Final Proof' }} />
        <Stack.Screen name="Rating" component={Rating} options={{ title: 'Rate Helper' }} />
        <Stack.Screen name="Wallet" component={Wallet} options={{ title: 'Wallet' }} />
        <Stack.Screen name="Chat" component={Chat} options={{ title: 'Chat' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
