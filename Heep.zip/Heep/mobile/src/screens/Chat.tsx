import React, { useEffect, useState } from 'react';
import { View, TextInput, Button, FlatList, Text } from 'react-native';
import { api } from '../api';
import { load } from '../storage';
export default function Chat({ route }: any) {
  const { taskId } = route.params;
  const [list, setList] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [userId, setUserId] = useState<number | null>(null);
  const fetchMsgs = async () => {
    const r = await api(`/chat/${taskId}`); setList(r);
  };
  useEffect(() => { (async () => { const u = await load('user'); setUserId(u?.id || null); fetchMsgs(); const int = setInterval(fetchMsgs, 2000); return () => clearInterval(int); })(); }, []);
  const send = async () => {
    if (!userId || !msg.trim()) return;
    await api(`/chat`, { method: 'POST', body: JSON.stringify({ task_id: taskId, sender_id: userId, message: msg }) });
    setMsg(''); fetchMsgs();
  };
  return (
    <View style={{ padding: 16, flex: 1 }}>
      <FlatList style={{ flex: 1 }} data={list} keyExtractor={(i)=>String(i.id||Math.random())}
        renderItem={({item}) => (
          <View style={{ paddingVertical: 6 }}>
            <Text style={{ fontWeight: '700' }}>{item.sender_id}</Text>
            <Text>{item.message}</Text>
          </View>
        )}/>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <TextInput value={msg} onChangeText={setMsg} placeholder="Type..." style={{ flex: 1, borderWidth:1, borderRadius:8, padding:8 }} />
        <Button title="Send" onPress={send} />
      </View>
    </View>
  );
}
