import React from 'react';
import { View, Button } from 'react-native';
export default function RoleSelect({ navigation }: any) {
  return (
    <View style={{ padding: 16, gap: 12 }}>
      <Button title="I Need Help (Create Task)" onPress={() => navigation.navigate('CreateTask')} />
      <Button title="I Can Help (Find Nearby Tasks)" onPress={() => navigation.navigate('AvailableTasks')} />
      <Button title="Wallet" onPress={() => navigation.navigate('Wallet')} />
    </View>
  );
}
