import React, { useState, useEffect } from 'react';
import { View, Button, Image, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { api } from '../api';
export default function EarlyProof({ route, navigation }: any) {
  const { taskId } = route.params;
  const [img, setImg] = useState<string | null>(null);
  const [coords, setCoords] = useState<{lat:number,lng:number}|null>(null);
  useEffect(() => { (async () => {
    await ImagePicker.requestCameraPermissionsAsync();
    await ImagePicker.requestMediaLibraryPermissionsAsync();
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      const loc = await Location.getCurrentPositionAsync({});
      setCoords({ lat: loc.coords.latitude, lng: loc.coords.longitude });
    }
  })(); }, []);
  const pick = async () => {
    const res = await ImagePicker.launchCameraAsync({ quality: 0.6 });
    if (!res.canceled) setImg(res.assets[0].uri);
  };
  const submit = async () => {
    try {
      const payload = { photo_url: img || 'local://photo.jpg', gps_lat: coords?.lat, gps_lng: coords?.lng };
      await api(`/tasks/${taskId}/early-proof`, { method: 'POST', body: JSON.stringify(payload) });
      Alert.alert('Submitted', 'Waiting requester confirmation (demo)');
      navigation.navigate('FinalProof', { taskId });
    } catch (e: any) { Alert.alert('Error', e.message); }
  };
  return (
    <View style={{ padding: 16, gap: 10 }}>
      <Button title="Capture Photo/Video" onPress={pick} />
      {img && <Image source={{ uri: img }} style={{ width: 200, height: 200, marginVertical: 10 }} />}
      <Button title="Submit Early Proof" onPress={submit} />
    </View>
  );
}
