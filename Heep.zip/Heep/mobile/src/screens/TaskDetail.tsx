import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert } from 'react-native';
import { api } from '../api';
import { load } from '../storage';
export default function TaskDetail({ route, navigation }: any) {
  const { task } = route.params;
  const [accepted, setAccepted] = useState(task.status !== 'open');
  const [trust, setTrust] = useState<number | null>(null);
  useEffect(() => {
    (async () => {
      if (task.helper_id) {
        const t = await api(`/users/${task.helper_id}/trust`);
        setTrust(t.trust_score ?? null);
      }
    })();
  }, [task.helper_id]);
  const accept = async () => {
    try {
      const user = await load('user');
      const updated = await api(`/tasks/${task.id}/accept`, { method: 'POST', body: JSON.stringify({ helper_id: user.id, countdown_minutes: 15 }) });
      setAccepted(true); Alert.alert('Accepted', 'Countdown started');
      navigation.navigate('EarlyProof', { taskId: task.id });
    } catch (e: any) { Alert.alert('Error', e.message); }
  };
  return (
    <View style={{ padding: 16, gap: 10 }}>
      <Text style={{ fontWeight: '800', fontSize: 18 }}>{task.title}</Text>
      <Text>{task.description}</Text>
      {trust !== null && <Text>Helper Trust: {trust}</Text>}
      {!accepted && <Button title="Accept Task" onPress={accept} />}
      {accepted && (
        <>
          <Button title="Submit Early Proof" onPress={() => navigation.navigate('EarlyProof', { taskId: task.id })} />
          <Button title="Open Chat" onPress={() => navigation.navigate('Chat', { taskId: task.id, title: task.title })} />
        </>
      )}
    </View>
  );
}
