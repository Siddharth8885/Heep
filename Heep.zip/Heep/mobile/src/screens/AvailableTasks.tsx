import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList, Alert } from 'react-native';
import * as Location from 'expo-location';
import { api } from '../api';
export default function AvailableTasks({ navigation }: any) {
  const [tasks, setTasks] = useState<any[]>([]);
  useEffect(() => { (async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permission denied'); return; }
    const loc = await Location.getCurrentPositionAsync({});
    const list = await api(`/tasks/available?lat=${loc.coords.latitude}&lng=${loc.coords.longitude}&radius_km=50`);
    setTasks(list);
  })(); }, []);
  return (
    <View style={{ padding: 16 }}>
      <FlatList
        data={tasks}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <View style={{ padding: 12, borderWidth:1, borderRadius:8, marginBottom:10 }}>
            <Text style={{ fontWeight: '700' }}>{item.title}</Text>
            <Text>{item.description}</Text>
            <Button title="View" onPress={() => navigation.navigate('TaskDetail', { task: item })} />
          </View>
        )}
      />
    </View>
  );
}
