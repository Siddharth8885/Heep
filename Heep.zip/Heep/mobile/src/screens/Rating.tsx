import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import { api } from '../api';
import { load } from '../storage';
export default function Rating({ route }: any) {
  const { taskId } = route.params;
  const [timeliness, setTimeliness] = useState('5');
  const [quality, setQuality] = useState('5');
  const [communication, setCommunication] = useState('5');
  const [reliability, setReliability] = useState('5');
  const [comment, setComment] = useState('Great job');
  const [helperId, setHelperId] = useState<number>(1);
  const [requesterId, setRequesterId] = useState<number>(1);
  useEffect(() => { (async () => { 
    const u = await load('user'); if (u) { setRequesterId(u.id); setHelperId(u.id); }
  })(); }, []);
  const submit = async () => {
    try {
      await api('/ratings', { method: 'POST', body: JSON.stringify({ task_id: taskId, helper_id: helperId, requester_id: requesterId, timeliness: +timeliness, quality: +quality, communication: +communication, reliability: +reliability, comment }) });
      Alert.alert('Thanks!', 'Rating submitted');
    } catch (e: any) { Alert.alert('Error', e.message); }
  };
  return (
    <View style={{ padding: 16, gap: 8 }}>
      <Text>Timeliness (1-5)</Text><TextInput value={timeliness} onChangeText={setTimeliness} keyboardType="numeric" style={{borderWidth:1,padding:8,borderRadius:8}} />
      <Text>Quality (1-5)</Text><TextInput value={quality} onChangeText={setQuality} keyboardType="numeric" style={{borderWidth:1,padding:8,borderRadius:8}} />
      <Text>Communication (1-5)</Text><TextInput value={communication} onChangeText={setCommunication} keyboardType="numeric" style={{borderWidth:1,padding:8,borderRadius:8}} />
      <Text>Reliability (1-5)</Text><TextInput value={reliability} onChangeText={setReliability} keyboardType="numeric" style={{borderWidth:1,padding:8,borderRadius:8}} />
      <Text>Comment</Text><TextInput value={comment} onChangeText={setComment} style={{borderWidth:1,padding:8,borderRadius:8}} />
      <Button title="Submit Rating" onPress={submit} />
    </View>
  );
}
