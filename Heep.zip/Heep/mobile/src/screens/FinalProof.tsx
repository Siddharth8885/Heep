import React, { useState } from 'react';
import { View, Button, Image, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { api } from '../api';
export default function FinalProof({ route, navigation }: any) {
  const { taskId } = route.params;
  const [img, setImg] = useState<string | null>(null);
  const pick = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({ quality: 0.6 });
    if (!res.canceled) setImg(res.assets[0].uri);
  };
  const submit = async () => {
    try {
      await api(`/tasks/${taskId}/final-proof`, { method: 'POST', body: JSON.stringify({ photo_url: img || 'local://final.jpg' }) });
      await api(`/tasks/${taskId}/confirm-completion?approve=true`, { method: 'POST' });
      Alert.alert('Completed', 'Payment released to helper wallet (demo)');
      navigation.navigate('Rating', { taskId });
    } catch (e: any) { Alert.alert('Error', e.message); }
  };
  return (
    <View style={{ padding: 16 }}>
      <Button title="Choose Final Photo" onPress={pick} />
      {img && <Image source={{ uri: img }} style={{ width: 200, height: 200, marginVertical: 10 }} />}
      <Button title="Submit Final & Confirm Completion" onPress={submit} />
    </View>
  );
}
