import React, { useEffect, useState } from 'react';
import { View, Text, FlatList } from 'react-native';
import { api } from '../api';
import { load } from '../storage';
export default function Wallet() {
  const [balance, setBalance] = useState(0);
  const [tx, setTx] = useState<any[]>([]);
  useEffect(() => { (async () => {
    const u = await load('user'); if (!u) return;
    const w = await api(`/users/${u.id}/wallet`);
    setBalance(w.balance); setTx(w.transactions || []);
  })(); }, []);
  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontWeight: '800', fontSize: 18 }}>Balance: ₹{(balance/100).toFixed(2)}</Text>
      <FlatList data={tx} keyExtractor={(i)=>String(i.id||Math.random())}
        renderItem={({item}) => (
          <View style={{ paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eee' }}>
            <Text>{item.type} • ₹{(item.amount/100).toFixed(2)}</Text>
            <Text>{item.created_at}</Text>
          </View>
        )}/>
    </View>
  );
}
