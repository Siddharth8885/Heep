import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import { api } from '../api';
import { save, load } from '../storage';
export default function SignUp({ navigation }: any) {
  const [phone, setPhone] = useState(''); const [name, setName] = useState('');
  const [role, setRole] = useState<'requester'|'helper'>('requester');
  useEffect(() => { load('user').then(u => { if (u) navigation.replace('RoleSelect'); }); }, []);
  const createUser = async () => {
    try { const user = await api('/users', { method: 'POST', body: JSON.stringify({ phone, name, role }) });
      await save('user', user); Alert.alert('Signed in as ' + (user.name || user.phone)); navigation.replace('RoleSelect');
    } catch (e: any) { Alert.alert('Error', e.message); }
  };
  return (
    <View style={{ padding: 16, gap: 10 }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>Create Account</Text>
      <Text>Phone</Text><TextInput value={phone} onChangeText={setPhone} keyboardType="phone-pad" style={{borderWidth:1,padding:10,borderRadius:8}} />
      <Text>Name</Text><TextInput value={name} onChangeText={setName} style={{borderWidth:1,padding:10,borderRadius:8}} />
      <View style={{ flexDirection: 'row', gap: 12, marginVertical: 8 }}>
        <Button title={role==='requester'?'Requester ✓':'Requester'} onPress={() => setRole('requester')} />
        <Button title={role==='helper'?'Helper ✓':'Helper'} onPress={() => setRole('helper')} />
      </View>
      <Button title="Continue" onPress={createUser} />
    </View>
  );
}
