import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert, Switch } from 'react-native';
import * as Location from 'expo-location';
import Field from '../components/Field';
import { api } from '../api';
import { load } from '../storage';
export default function CreateTask() {
  const [title, setTitle] = useState('Pickup Documents');
  const [description, setDescription] = useState('Collect and deliver.');
  const [coords, setCoords] = useState<{lat:number,lng:number}|null>(null);
  const [deadline, setDeadline] = useState(new Date(Date.now()+3600*1000).toISOString());
  const [budget, setBudget] = useState('5000');
  const [urgent, setUrgent] = useState(false);
  const [requesterId, setRequesterId] = useState<number|undefined>();
  useEffect(() => { (async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Location permission denied'); return; }
    const loc = await Location.getCurrentPositionAsync({}); setCoords({ lat: loc.coords.latitude, lng: loc.coords.longitude });
    const u = await load('user'); setRequesterId(u?.id);
  })(); }, []);
  const submit = async () => {
    try {
      if (!coords || !requesterId) return Alert.alert('Missing data');
      const body = { title, description, lat: coords.lat, lng: coords.lng, deadline, budget: parseInt(budget), urgent, requester_id: requesterId };
      const task = await api('/tasks', { method: 'POST', body: JSON.stringify(body) });
      Alert.alert('Task created', `ID ${task.id}`);
    } catch (e: any) { Alert.alert('Error', e.message); }
  };
  return (
    <View style={{ padding: 16 }}>
      <Field label="Title" value={title} onChangeText={setTitle} />
      <Field label="Description" value={description} onChangeText={setDescription} multiline />
      <Field label="Deadline (ISO)" value={deadline} onChangeText={setDeadline} />
      <Field label="Budget (paise)" value={budget} onChangeText={setBudget} keyboardType="numeric" />
      <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 8 }}>
        <Text style={{ marginRight: 8 }}>Urgent</Text>
        <Switch value={urgent} onValueChange={setUrgent} />
      </View>
      <Button title="Use Current Location" onPress={async () => {
        const loc = await Location.getCurrentPositionAsync({});
        setCoords({ lat: loc.coords.latitude, lng: loc.coords.longitude });
      }} />
      <Button title="Create Task" onPress={submit} />
    </View>
  );
}
